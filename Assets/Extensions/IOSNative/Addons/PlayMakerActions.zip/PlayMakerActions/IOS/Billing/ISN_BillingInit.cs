using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Init billing. Best practice to do this on appplicaton start")]
	public class ISN_BillingInit : FsmStateAction {


		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;

		public override void Reset() {
		
		}



		public override void OnEnter() {

			bool IsInEdditorMode = false;

			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif


			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.STORE_KIT_INITIALIZED, OnInit);
			IOSInAppPurchaseManager.instance.loadStore();

		}


		private void OnInit() {
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.STORE_KIT_INITIALIZED, OnInit);

			Fsm.Event(successEvent);
			Finish();
		}

	}
}

