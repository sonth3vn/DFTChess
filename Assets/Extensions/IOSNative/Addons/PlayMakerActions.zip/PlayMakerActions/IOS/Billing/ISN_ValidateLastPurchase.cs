using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class ISN_ValidateLastPurchase : FsmStateAction {
		
		
		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit initlization is failed")]
		public FsmEvent failEvent;

		public bool useSendBoxUrl = true;


		public FsmInt status;
		public FsmString receipt;
		public FsmString originalJSON;
		

		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			string url = IOSInAppPurchaseManager.APPLE_VERIFICATION_SERVER;

			if(useSendBoxUrl) {
				url = IOSInAppPurchaseManager.SANDBOX_VERIFICATION_SERVER;
			}


			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.VERIFICATION_RESPONSE, OnVerificationResponce);
			IOSInAppPurchaseManager.instance.verifyLastPurchase(url);

			
		}
		

		
		private void OnVerificationResponce(CEvent e) {
			IOSStoreKitVerificationResponse resp = e.data as IOSStoreKitVerificationResponse;
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.VERIFICATION_RESPONSE, OnVerificationResponce);


			status.Value 		= resp.status;
			receipt.Value 		= resp.receipt;
			originalJSON.Value 	= resp.originalJSON;

			if(resp.status == 0) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			Finish();
			
		}

		
	}
}


