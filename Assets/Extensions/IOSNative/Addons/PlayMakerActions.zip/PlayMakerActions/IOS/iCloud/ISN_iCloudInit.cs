using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - iCloud")]
	public class ISN_iCloudInit : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public override void OnEnter() {

			bool IsInEdditorMode = false;

			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif

			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			iCloudManager.instance.init ();
			iCloudManager.instance.addEventListener (iCloudManager.CLOUD_INITIALIZED, OnInit);
			iCloudManager.instance.addEventListener (iCloudManager.CLOUD_INITIALIZE_FAILED, OnInitFailed);
		}


		private void OnInit() {
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_INITIALIZED, OnInit);
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_INITIALIZE_FAILED, OnInitFailed);

			Fsm.Event(successEvent);
			Finish();
		}

		private void OnInitFailed() {
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_INITIALIZED, OnInit);
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_INITIALIZE_FAILED, OnInitFailed);

			Fsm.Event(failEvent);
			Finish();
		}
	}
}

