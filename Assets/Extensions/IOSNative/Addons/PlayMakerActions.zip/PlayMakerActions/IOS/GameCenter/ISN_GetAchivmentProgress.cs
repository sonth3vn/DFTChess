﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetAchivmentProgress : FsmStateAction {


		public FsmString achievementId;
		public FsmFloat achievementProgress;

		
		public override void Reset() {
			
		}


		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				achievementProgress = 0;
				Finish();
				return;
			}

			if(GameCenterManager.IsAchievmentInfoLoaded) {
				achievementProgress = GameCenterManager.getAchievementProgress(achievementId.Value);
				Finish();
			} else {
				GameCenterManager.dispatcher.addEventListener (GameCenterManager.GAME_CENTER_ACHIEVEMENTS_LOADED, OnAchievementsLoaded);
			}



			
		}


		//--------------------------------------
		//  EVENTS
		//--------------------------------------
		
		private void OnAchievementsLoaded() {
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_ACHIEVEMENTS_LOADED, OnAchievementsLoaded);
			achievementProgress = GameCenterManager.getAchievementProgress(achievementId.Value);
			Finish();
		}



	}
}

