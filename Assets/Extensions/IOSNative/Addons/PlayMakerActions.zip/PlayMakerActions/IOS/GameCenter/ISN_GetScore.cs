﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetScore : FsmStateAction {

		public FsmString leaderboardId;
		public FsmInt score;


		public override void OnEnter() {

			GCLeaderBoard board = GameCenterManager.GetLeaderBoard(leaderboardId.Value);
			if(board != null) {
				GCScore s =  board.GetCurrentPlayerScore(GCBoardTimeSpan.ALL_TIME, GCCollectionType.GLOBAL);
				if(s != null) {
					score.Value = s.GetIntScore();
					Finish();
					return;
				}

			}

			SendScoreLoadRequest();


			
		}

		private void SendScoreLoadRequest() {
			GameCenterManager.dispatcher.addEventListener (GameCenterManager.GAME_CENTER_LEADER_BOARD_SCORE_LOADED, OnLeaderBoarScoreLoaded);
			GameCenterManager.getScore(leaderboardId.Value);
		}


		private void OnLeaderBoarScoreLoaded(CEvent e) {
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_LEADER_BOARD_SCORE_LOADED, OnLeaderBoarScoreLoaded);

			GCScore  data = e.data as GCScore;
			score.Value = data.GetIntScore();
			Finish();
		}

	}
}

