﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_RetriveGCPlayerId : FsmStateAction {
		

		public FsmString playerId;
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public override void Reset() {
			
		}
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				playerId.Value = "1";
				Finish();
				return;
			}
			



			GameCenterManager.dispatcher.addEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTICATED, OnAuth);
			GameCenterManager.dispatcher.addEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTIFICATION_FAILED, OnAuthFailed);

			if(GameCenterManager.IsInited) {
				OnAuth();
			} else {
				GameCenterManager.init();
			}

			
		}
		
		
		private void OnAuth() {
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTICATED, OnAuth);
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTIFICATION_FAILED, OnAuthFailed);

			playerId.Value = GameCenterManager.player.playerId;
			Fsm.Event(successEvent);
			Finish();
		}
		
		private void OnAuthFailed() {
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTICATED, OnAuth);
			GameCenterManager.dispatcher.removeEventListener (GameCenterManager.GAME_CENTER_PLAYER_AUTHENTIFICATION_FAILED, OnAuthFailed);		

			playerId.Value = "0";
			Fsm.Event(failEvent);
			Finish();
		}
		
		
	}
}