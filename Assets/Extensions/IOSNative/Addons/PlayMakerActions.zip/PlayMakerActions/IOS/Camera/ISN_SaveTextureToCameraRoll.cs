using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Camera")]
	public class ISN_SaveTextureToCameraRoll : FsmStateAction {

		public FsmTexture texture;
		
		public override void OnEnter() {
			IOSCamera.instance.SaveTextureToCameraRoll(texture.Value as Texture2D);
			Finish();
		}



	}
}



