using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSPTwitterNativePost : FsmStateAction {

		public FsmString message;



		public override void OnEnter() {

			SPShareUtility.TwitterShare(message.Value);
			Finish();

		}


	}
}


